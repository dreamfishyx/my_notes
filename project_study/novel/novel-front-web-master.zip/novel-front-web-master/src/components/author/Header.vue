 <template>
  <div class="header">
    <div class="mainNav" id="mainNav">
        <div class="box_center cf" style="text-align: center;height: 44px;line-height: 48px;color: #fff;font-size: 16px;">

            小说精品屋作家管理

        </div>
    </div>
</div>
</template>

<script>
export default {
  name: "AuthorHeader"
};
</script>