1. 初始状态下，MySQL 只需要执行 `novel.sql` 文件即可正常运行本系统
2. 只有开启 XXL-JOB 的功能，才需要执行 `xxl-job.sql` 文件
3. 只有开启 ShardingSphere-JDBC 的功能，才需要执行 `shardingsphere-jdbc.sql` 文件

