IntelliJ IDEA 中导入 `intellij-java-google-style.xml` 文件：

`Preferences` => `Editor` => `Code Style` => `Java` => `Schema` => `Import Schema`